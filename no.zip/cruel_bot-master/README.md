# cruel_bot
The best source based on New tg-cli

آموزش نصب

```sh


git clone https://github.com/CRUELTM/cruel_bot.git


cd cruel_bot


cd tg ; wget https://valtman.name/files/telegram-cli-1124 ; cd .. ; ./run


```
بعد از این کار از شما شماره تلفن میخواهد
بعد وارد نمودن شماره ربات لانچ خواهد شد

* نوشته شده بر اساس تی جی جدید
* قابلیت افزودن پلاگین
* غیر قابل ادیت فایل های اصلی
* هر پلاگینی که برای این سورس مینویسید باید اوپن شود
* برای دریافت جدید ترین پلاگین ها میتوانید به کانال تیم کرول مراجعه کنید
[CRUEL TEAM | کانال تیم کرول](https://telegram.me/cruel_team)

#دستورات
###locks
>!lock (links,edit,fwd,username,spam)
>>!lock links


###mutes
>!mute (all,photo,document,gif,audio,voice,video)
>>!mute all


###settings
>!settings


###promote and demote
>!promote  --by reply or id
>>!demote  --by reply or id

###set owner
>!setowner  --by reply or id
